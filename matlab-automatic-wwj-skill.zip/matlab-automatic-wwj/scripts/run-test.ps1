[CmdletBinding()]
param(
    [ValidateSet('all', 'simulink', 'control')]
    [string]$Test = 'all',
    [string]$MatlabExecutable,
    [string]$OutputDirectory = (Join-Path (Get-Location).Path 'matlab-skill-tests'),
    [switch]$Headless,
    [ValidateRange(30, 3600)]
    [int]$TimeoutSeconds = 600
)

$ErrorActionPreference = 'Stop'
$skillRoot = Split-Path -Parent $PSScriptRoot
if (-not $MatlabExecutable) {
    $matlabCommand = Get-Command matlab.exe -ErrorAction SilentlyContinue
    if (-not $matlabCommand) {
        throw 'MATLAB was not found on PATH. Supply -MatlabExecutable with the full path to matlab.exe.'
    }
    $MatlabExecutable = $matlabCommand.Source
}
$MatlabExecutable = (Resolve-Path -LiteralPath $MatlabExecutable).Path
if (-not (Test-Path -LiteralPath $MatlabExecutable -PathType Leaf)) {
    throw 'MatlabExecutable must point to a file.'
}
$outputRoot = [IO.Path]::GetFullPath($OutputDirectory)
New-Item -ItemType Directory -Path $outputRoot -Force | Out-Null
$runToken = (Get-Date -Format 'yyyyMMdd_HHmmss_fff') + '_' + [guid]::NewGuid().ToString('N').Substring(0, 8)
$launchDir = Join-Path $outputRoot ('launch_' + $runToken)
$stagedScripts = Join-Path $launchDir 'scripts'
New-Item -ItemType Directory -Path $stagedScripts | Out-Null
$selectedFiles = switch ($Test) {
    'simulink' { @('codex_desktop_demo.m') }
    'control' { @('control_theory_plots.m') }
    'all' { @('codex_desktop_demo.m', 'control_theory_plots.m') }
}
foreach ($name in $selectedFiles) {
    Copy-Item -LiteralPath (Join-Path $skillRoot ('assets\' + $name)) -Destination (Join-Path $stagedScripts $name)
}

function ConvertTo-MatlabLiteral([string]$Value) {
    return "'" + $Value.Replace("'", "''") + "'"
}
$visibleLiteral = if ($Headless) { 'false' } else { 'true' }
$statusPath = Join-Path $launchDir 'launch_status.json'
$launcherPath = Join-Path $launchDir 'run_skill_tests.m'
$logPath = Join-Path $launchDir 'matlab.log'
$lines = [Collections.Generic.List[string]]::new()
$lines.Add('% Generated runner for matlab-automatic-wwj test routines.')
$lines.Add('codex_launch_summary = struct(''status'',''running'',''skill'',''matlab-automatic-wwj'',''reports'',{{}});')
$lines.Add('codex_launch_status_path = ' + (ConvertTo-MatlabLiteral $statusPath) + ';')
$lines.Add('writeLaunchStatus(codex_launch_status_path, codex_launch_summary);')
$lines.Add('try')
foreach ($name in $selectedFiles) {
    $path = Join-Path $stagedScripts $name
    if ($Headless) {
        $lines.Add('    codex_figures_before = findall(groot,''Type'',''figure'');')
    }
    $lines.Add('    codex_demo_config = struct(''output_root'',' + (ConvertTo-MatlabLiteral $outputRoot) + ',''visible'',' + $visibleLiteral + ');')
    $lines.Add('    run(' + (ConvertTo-MatlabLiteral $path) + ');')
    $lines.Add('    codex_run_report = jsondecode(fileread(codex_demo_last_summary_path));')
    $lines.Add('    assert(strcmp(codex_run_report.status,''success''),''A test routine did not succeed.'');')
    $lines.Add('    assert(codex_run_report.validation.passed,''Numerical validation did not pass.'');')
    if ($Headless) {
        $lines.Add('    codex_figures_after = findall(groot,''Type'',''figure'');')
        $lines.Add('    assert(numel(codex_figures_before)==numel(codex_figures_after) && all(ismember(codex_figures_before,codex_figures_after)),''A headless routine left a figure open or closed an existing figure.'');')
        $lines.Add('    if strcmp(codex_run_report.routine,''simulink''), assert(~bdIsLoaded(codex_run_report.model.name),''A headless routine left its model loaded.''); end')
    }
    $lines.Add('    codex_launch_summary.reports{end+1} = codex_demo_last_summary_path;')
    $lines.Add('    writeLaunchStatus(codex_launch_status_path, codex_launch_summary);')
}
$lines.Add('    codex_launch_summary.status = ''success'';')
$lines.Add('    writeLaunchStatus(codex_launch_status_path, codex_launch_summary);')
$lines.Add('    fprintf(''MATLAB_SKILL_TESTS_SUCCESS=%s\n'', codex_launch_status_path);')
$lines.Add('catch codex_launch_failure')
$lines.Add('    codex_launch_summary.status = ''failed'';')
$lines.Add('    codex_launch_summary.error = getReport(codex_launch_failure,''extended'',''hyperlinks'',''off'');')
$lines.Add('    writeLaunchStatus(codex_launch_status_path, codex_launch_summary);')
$lines.Add('    rethrow(codex_launch_failure);')
$lines.Add('end')
$lines.Add('function writeLaunchStatus(path, value)')
$lines.Add('    fid=fopen(path,''w'',''n'',''UTF-8'');')
$lines.Add('    assert(fid~=-1,''Cannot write launch status.'');')
$lines.Add('    closer=onCleanup(@() fclose(fid));')
$lines.Add('    fprintf(fid,''%s\n'',jsonencode(value,''PrettyPrint'',true));')
$lines.Add('end')
[IO.File]::WriteAllText($launcherPath, ($lines -join [Environment]::NewLine), [Text.UTF8Encoding]::new($false))

$runExpression = 'run(' + (ConvertTo-MatlabLiteral $launcherPath.Replace('\', '/')) + ')'
if ($Headless) {
    $argumentLine = '-wait -batch "' + $runExpression + '" -logfile "' + $logPath + '"'
    $matlabProcess = Start-Process -FilePath $MatlabExecutable -ArgumentList $argumentLine -WorkingDirectory $launchDir -WindowStyle Hidden -PassThru
} else {
    $interactiveExpression = "try, $runExpression; catch ME, disp(getReport(ME,'extended','hyperlinks','off')); end"
    $argumentLine = '-r "' + $interactiveExpression + '" -logfile "' + $logPath + '"'
    $matlabProcess = Start-Process -FilePath $MatlabExecutable -ArgumentList $argumentLine -WorkingDirectory $launchDir -WindowStyle Normal -PassThru
}
$launchInfo = [ordered]@{
    skill = 'matlab-automatic-wwj'
    test = $Test
    mode = $(if ($Headless) { 'headless' } else { 'desktop' })
    launcher_pid = $matlabProcess.Id
    launch_directory = $launchDir
    status_file = $statusPath
    log_file = $logPath
    matlab_executable = $MatlabExecutable
}
$launchInfo | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $launchDir 'launch.json') -Encoding utf8
$launchInfo | ConvertTo-Json
if ($Headless) {
    if (-not $matlabProcess.WaitForExit($TimeoutSeconds * 1000)) {
        throw "MATLAB test exceeded $TimeoutSeconds seconds. The process is still running; inspect $statusPath and $logPath before retrying."
    }
    $matlabProcess.Refresh()
    if (-not (Test-Path -LiteralPath $statusPath)) {
        throw "MATLAB exited without a test report. Inspect $logPath."
    }
    $completed = Get-Content -LiteralPath $statusPath -Raw -Encoding utf8 | ConvertFrom-Json
    if ($matlabProcess.ExitCode -ne 0 -or $completed.status -ne 'success') {
        throw "MATLAB test failed (exit $($matlabProcess.ExitCode)). Inspect $statusPath and $logPath."
    }
    Write-Output ('MATLAB_SKILL_TESTS_SUCCESS=' + $statusPath)
} else {
    Write-Output ('MATLAB desktop launched. Wait for status=success in ' + $statusPath + '; process creation alone is not a passed test.')
}
