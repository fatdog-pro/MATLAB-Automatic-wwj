# matlab-automatic-wwj 用户测试例程

这两份例程用于验证智能体能实际调用本机 MATLAB、计算结果并保存文件。默认显示真实窗口，运行结束后保留窗口供用户操作；自动验证可关闭显示。每个脚本都包含自己的辅助函数，可以单独复制到用户工作目录使用，不依赖本 skill 的安装位置或项目 `setup` 目录。

| 例程 | 实际执行内容 | 依赖 | GUI 模式中的窗口 |
| --- | --- | --- | --- |
| [codex_desktop_demo.m](../assets/codex_desktop_demo.m) | 创建 Step → 1/(2s+1) 模型，分支接 To Workspace 和 Scope，运行 10 s 并对照解析解 | MATLAB、Simulink | Simulink 模型、Scope、响应图；有 MATLAB Desktop 时在编辑器中显示脚本 |
| [control_theory_plots.m](../assets/control_theory_plots.m) | 使用 `tf`、`step`、`stepinfo`、`bode`、`rlocus` 和 `feedback` 计算后绘图 | MATLAB、Control System Toolbox | 一个包含阶跃、根轨迹、Bode 幅频和相频图的 Figure；有 Desktop 时显示脚本 |

普通代码例程不调用 Simulink。Simulink 例程的曲线取自实际 `SimulationOutput`，然后与解析解逐点比较。

## 从智能体发起

安装并接通执行通道后，可以这样说：

> 使用 $matlab-automatic-wwj 运行内置的两个用户测试例程，在真实 MATLAB 窗口里展示，保留模型、Scope 和作图窗口，把结果保存到我指定的测试目录，并核对两份 summary.json。

自动验证的示例：

> 使用 $matlab-automatic-wwj 无窗口运行两个内置测试例程，读取数值验收结果并告诉我输出目录。

GUI 演示需要具有可交互显示的本地 MATLAB 会话。如果当前 MCP 会话使用无桌面模式，可使用下面的启动脚本打开 MATLAB Desktop。仅执行无窗口验证不能证明真实窗口已显示。

## Windows 一条命令运行

在 skill 目录下，使用 [scripts/run-test.ps1](../scripts/run-test.ps1)。启动器会先复制资产脚本到本次测试目录，再显式传入输出父目录，因此不会向 skill 安装目录写测试结果。

```powershell
# 两个例程，显示并保留真实窗口
.\scripts\run-test.ps1 -Test all -OutputDirectory 'D:\MATLAB用户测试'

# 仅测试 Simulink 或普通控制原理作图
.\scripts\run-test.ps1 -Test simulink -OutputDirectory 'D:\MATLAB用户测试'
.\scripts\run-test.ps1 -Test control -OutputDirectory 'D:\MATLAB用户测试'

# 自动验证：不打开编辑器、模型、Scope 或可见 Figure
.\scripts\run-test.ps1 -Test all -Headless -OutputDirectory 'D:\MATLAB用户测试'

# 自动发现失败时，指定本机实际 MATLAB 可执行文件
.\scripts\run-test.ps1 -Test all -Headless -OutputDirectory 'D:\MATLAB用户测试' -MatlabExecutable 'D:\360\bin\matlab.exe'
```

`D:\360\bin\matlab.exe` 只是当前机器的示例。换机器后应使用实际安装路径。

## 直接在 MATLAB 中运行

在运行前设置 `codex_demo_config`：

```matlab
% 改成实际 skill 安装位置，或已复制资产的目录。
skillDir = fullfile(getenv('USERPROFILE'), '.codex', 'skills', 'matlab-automatic-wwj');
testOutputRoot = fullfile(pwd, 'matlab-skill-tests');
codex_demo_config = struct('output_root', testOutputRoot, 'visible', true);

run(fullfile(skillDir, 'assets', 'codex_desktop_demo.m'));
simulinkSummaryPath = codex_demo_last_summary_path;

run(fullfile(skillDir, 'assets', 'control_theory_plots.m'));
controlSummaryPath = codex_demo_last_summary_path;
```

将 `visible` 改为逻辑值 `false` 即可自动验证。同样会计算、校验并保存图和数据，不要求 `usejava('desktop')` 为真。无窗口运行完成或出错时只关闭本次创建的图和模型；GUI 模式会保留本次窗口。例程不会修改 `groot` 默认值或清空用户工作区，也不会执行全局关图、关模型命令。

如果把 `.m` 单独复制到工作目录并按文件名运行，默认配置为 `visible=true`、`output_root=fullfile(pwd,'matlab-skill-tests')`。注意 MATLAB 的 `run(绝对路径)` 会临时切换到脚本所在目录，所以这种调用方式应像上例一样，在 `run` 之前显式设置输出目录。启动器已经处理了这个细节。

每次脚本调用都创建带时间与唯一标识的子目录，不覆盖之前的测试。两例均在脚本工作区和 MATLAB base workspace 设置 `codex_demo_last_summary_path`，并打印 `MATLAB_AGENT_RESULT=<summary.json绝对路径>`。运行失败会保存 `status="failed"` 并向调用者抛出错误；输出目录无法创建等前置错误由启动器或调用者报告，不能作为通过处理。

## 检查什么才算通过

读取各自的 `summary.json`，同时检查 `status="success"`、`validation.passed=true` 和所需输出文件真实存在且非空。窗口信息在 `display` 中，状态不会使用 `ready` 代替计算成功。

| 检查项 | 验收条件 |
| --- | --- |
| Simulink 一阶响应 | 0～10 s，至少 1001 个有限且严格递增时间样本，最大间隔不超过约 0.01 s；与 `1-exp(-t/2)` 最大绝对误差小于 `1e-4` |
| 二阶阶跃响应 | 五个阻尼比 `0.2、0.5、0.7、1、1.5`，每组 2401 个样本；与分别适用的解析解最大误差小于 `1e-8` |
| 超调量 | `stepinfo` 结果与理论值差小于 0.01 个百分点；上升时间及调节时间等指标为有限值 |
| Bode | 800 个频率点；幅值和相位重建的复数响应，与传递函数代入 `s=jω` 得到的独立结果最大误差小于 `1e-10` |
| 根轨迹 | 三条分支、1501 个增益；特征多项式的归一化残差小于 `1e-10`；K=69 稳定、K=71 不稳定，K=70 的临界极点验证通过 |
| GUI 展示 | `visible_requested=true`，实际窗口可见；Simulink 模型、Scope 和响应图均已打开，普通例程四面板 Figure 已打开 |

两个例程使用不同的系统：阶跃与 Bode 演示二阶系统，根轨迹独立使用 `L(s)=1/[s(s+2)(s+5)]`。后者在单位负反馈下的稳定区间为 `0<K<70`，不包含端点。

## 输出文件

- Simulink 例程：真实 `.slx` 模型、`response.mat`、`response.csv`、`response.png`、`summary.json`。支持模型画布导出的环境还会生成 `model.png`；应检查 `model_image_status="exported"`。无显示环境可能不支持此项，摘要会记录 `unavailable` 和原因；若用户明确要求模型图，需要补齐该文件。
- 普通 MATLAB 例程：`control_theory.png`、可编辑的 `control_theory.fig`、`control_data.mat`、阶跃指标 CSV、五组阶跃响应 CSV、Bode CSV、根轨迹 CSV 和 `summary.json`。

Simulink 响应图上的 `Run Simulink again` 按钮会重新仿真、验证并更新本次运行的数据和摘要；按钮重跑失败也会把该摘要标为 `failed`。修改了模型方程后，原例程的解析验收条件可能不再适用，应先同步修改验证逻辑。
