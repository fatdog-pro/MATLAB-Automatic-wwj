# 本机 Codex 配置与接入方式

## 本机配置（2026-09-09）

- MATLAB R2025a：`D:\360\bin\matlab.exe`
- 项目：`D:\手机图片\matlab-agent`
- MathWorks 官方 MCP v0.13.0：`D:\手机图片\matlab-agent\bin\matlab-mcp-server-windows-x64.exe`
- Codex 用户配置：`C:\Users\15063\.codex\config.toml`
- Skill：`C:\Users\15063\.codex\skills\matlab-automatic-wwj`
- 豆包工作电脑版的配置教程见 [doubao-mcp.md](doubao-mcp.md)。Skill 名称是 `matlab-automatic-wwj`，MCP 服务器名称仍是 `matlab`。

推荐配置片段：

```toml
[mcp_servers.matlab]
command = 'D:\手机图片\matlab-agent\bin\matlab-mcp-server-windows-x64.exe'
args = ['--matlab-root=D:\360', '--matlab-session-mode=new', '--matlab-display-mode=nodesktop', '--initial-working-folder=D:\手机图片\matlab-agent', '--disable-telemetry=true']
env_vars = ["WINDIR"]
startup_timeout_sec = 180
tool_timeout_sec = 300
```

配置保存后，在 Codex 的 MCP 设置中重新启动该服务，必要时重启 Codex。新会话中发现工具再判断是否成功加载；配置文件存在本身不是连通证据。`new` 创建本次服务自己的 MATLAB 会话；当前没有配置连接用户已打开的 MATLAB 窗口。

上面的 Codex 配置是后台计算模式。需要真实窗口演示时优先使用 [test-routines.md](test-routines.md) 中的桌面启动器；也可在用户希望一直可见时将当前客户端连接器的 `--matlab-display-mode=nodesktop` 改成 `--matlab-display-mode=desktop` 并重启该连接器。不要据此修改其他客户端的配置。新进程启动不等于成功连接到已有 MATLAB 窗口。

MCP 未加载但需要立即运行时，PowerShell 示例：

```powershell
& 'D:\360\bin\matlab.exe' -batch "run('D:/手机图片/matlab-agent/examples/codex_first_order_demo.m')"
```

中文或有空格的路径必须作为完整参数传递；MATLAB 字符串内的单引号需加倍。MATLAB 首次启动可能需要宿主侧文件系统访问，以执行工具实际权限检查为准。

## 可复用范围

| 宿主 | 接法 | 当前边界 |
|---|---|---|
| Codex 等本地 stdio MCP 客户端 | 启动官方 MCP exe，复用本 skill | 不同机器须修改路径并拥有相应 MATLAB/Simulink 许可 |
| 豆包工作电脑版 | 新建自定义连接器，选择本地电脑与 STDIO，直接填写官方 MATLAB MCP 命令 | 已有一手接入文档支持；本机尚未在豆包实际调用。详见专门教程 |
| 扣子 | 将执行层适配为受认证的 Streamable HTTP/SSE | 官方文档暂不支持 stdio；本次未实现 HTTP 适配，不作为豆包工作版配置的替代 |
| 基于豆包模型 API 的自建 Agent | 使用 Function Calling，工具执行器在 MATLAB 所在电脑执行 | 模型 API 与豆包消费聊天是不同接入入口 |
| 豆包其他入口、手机、网页 | 先核实该版本是否提供同样的自定义连接器入口 | 不将工作电脑版能力或本机路径自动推广至其他设备 |

当前没有部署 HTTP 桥接，也没有实际登录连接豆包或扣子。豆包工作电脑版的本地 STDIO 路线不需要 HTTP 桥接。未来远程执行须使用该用户有权使用的 MATLAB 会话和适当认证；官方服务并非供多个用户共享的 MATLAB 计算服务器。

## 官方资料

- [MathWorks MATLAB MCP Server](https://github.com/matlab/matlab-mcp-server) — 安装、工具、Windows Codex 的 WINDIR 设置与许可范围。
- [固定版本 v0.13.0](https://github.com/matlab/matlab-mcp-server/releases/tag/v0.13.0) — 本次二进制来源；校验清单保存在项目 setup/release.json。
- [Codex MCP 配置](https://learn.chatgpt.com/docs/extend/mcp?surface=cli) — stdio/HTTP、超时与配置位置。
- [Simulink Agentic Toolkit](https://github.com/matlab/simulink-agentic-toolkit) — 可选的模型读取、编辑、诊断专用扩展；本次未安装，基础 Simulink 编程建模无需该扩展。
- [扣子 MCP](https://docs.coze.cn/mcp) 与 [MCP 插件](https://docs.coze.cn/guides_create_a_plugin_based_on_mcp)。
- [MediaClaw 的豆包工作接入文档](https://mediaclaw.app/docs/agent/setup) 与 [flomo 的豆包连接器教程](https://help.flomoapp.com/advance/mcp/token.html) — 服务提供商发布的一手集成说明；不是豆包官方产品手册。
- [豆包模型 Function Calling](https://www.volcengine.com/docs/82379/1958524?lang=zh)。
