# 豆包工作电脑版连接 MATLAB MCP

本页供 `matlab-automatic-wwj` 技能在豆包工作电脑版接入本机 MATLAB 时使用。技能名为 `matlab-automatic-wwj`，MCP 服务器名为 `matlab`，两者分别配置。

资料核对日期：2026-09-09。已确认豆包工作提供本地 STDIO 自定义连接器，可以直接启动 MathWorks 官方 MATLAB MCP 程序。本项目已验证本机 MCP 与 MATLAB 的调用；**尚未登录豆包配置连接器或完成豆包实际调用**。下面是可填写的配置教程，不能作为豆包连通成功记录。

## 1. 确认本机文件

以下是当前 Windows 机器的配置。换电脑后先发现实际安装路径，并替换全部机器路径。

| 项目 | 当前机器的值 |
| --- | --- |
| MATLAB | R2025a，安装根目录 `D:\360` |
| MATLAB 可执行文件 | `D:\360\bin\matlab.exe` |
| MathWorks MCP | v0.13.0，`D:\手机图片\matlab-agent\bin\matlab-mcp-server-windows-x64.exe` |
| 工作目录 | `D:\手机图片\matlab-agent` |
| 本技能安装后的资产目录 | `C:\Users\15063\.codex\skills\matlab-automatic-wwj\assets` |
| 测试输出父目录 | `D:\手机图片\matlab-agent\test-results` |

运行前确认 MCP 程序、MATLAB 和要调用的脚本确实存在。技能可以另存到其他位置，只要豆包启动的 MATLAB 能访问对应绝对路径。复制或安装技能与添加 MCP 连接器是两个步骤；仅上传技能不会自动创建执行连接。

## 2. 新建本地 STDIO 连接器

1. 打开并登录**豆包工作电脑版**。
2. 左侧进入 **技能 · 连接器 · 伙伴**。
3. 右上角选择 **新建 → 新建自定义连接器**。
4. 运行位置选择 **本地电脑**，传输类型选择 **STDIO**。
5. 按下表填写。

| 表单字段 | 填写值 |
| --- | --- |
| 服务器名称 | `matlab` |
| 传输类型 | `STDIO` |
| 命令 | `D:\手机图片\matlab-agent\bin\matlab-mcp-server-windows-x64.exe` |
| 环境变量名称 | `WINDIR` |
| 环境变量值 | `C:\Windows` |

在 **参数** 中点击 **+ 添加**，每行分别添加一个参数：

```text
--matlab-root=D:\360
--matlab-session-mode=new
--matlab-display-mode=nodesktop
--initial-working-folder=D:\手机图片\matlab-agent
--disable-telemetry=true
```

命令字段只填写程序路径；不要把所有参数拼到命令字段里。表单字段和每条参数不用添加外层引号，中文和空格路径应保持为一个完整字段。`--matlab-root` 指向安装根目录，不能填成 `D:\360\bin`。

`WINDIR` 的值已在本机读取确认为 `C:\Windows`。这是环境变量的键和值，不能把 Codex TOML 的 `env_vars = ["WINDIR"]` 原样填入豆包表单。本地 STDIO 配置不需要服务器 URL、HTTP Header 或豆包模型 API Key。

入口、任务选择连接器和本机使用范围由 [flomo 官方集成文档](https://help.flomoapp.com/advance/mcp/token.html)记载；**本地电脑 → STDIO** 由 [MediaClaw 官方集成文档](https://mediaclaw.app/docs/agent/setup)明确记载。STDIO 表单名称与逐项添加参数的细节来自 [2026-09-02 Windows 用户一手实测](https://zhimayuandi.com/en/blog/doubao-custom-mcp-connectors/)。最后一项是作者实际配置记录，前两项是服务提供商官方文档，均不应标成豆包官方产品手册。

### 字段对照 JSON

以下只用于检查命令、参数和环境变量对应关系。**未核实豆包支持直接导入该 JSON，也未核实它使用的本地配置文件位置。** 实际配置优先使用上面的表单。

```json
{
  "mcpServers": {
    "matlab": {
      "type": "stdio",
      "command": "D:\\手机图片\\matlab-agent\\bin\\matlab-mcp-server-windows-x64.exe",
      "args": [
        "--matlab-root=D:\\360",
        "--matlab-session-mode=new",
        "--matlab-display-mode=nodesktop",
        "--initial-working-folder=D:\\手机图片\\matlab-agent",
        "--disable-telemetry=true"
      ],
      "env": {
        "WINDIR": "C:\\Windows"
      }
    }
  }
}
```

6. 点击 **保存**，查看连接器状态并确认已启用。
7. 新建工作任务，在输入框下方 **连接器** 中选中 `matlab`，再做实际调用测试。显示“已安装”或开关已启用，只说明配置状态，不能替代工具运行结果。

## 3. 先验证连通

可以给豆包发送：

> 请使用 matlab 连接器，先调用 detect_matlab_toolboxes，报告 MATLAB 版本与可用工具箱；再调用 evaluate_matlab_code，实际执行 disp(2+2); disp(version); disp(usejava('desktop'));。给出工具返回结果。只有实际调用成功后，才报告 MATLAB 已接通。

工具参数以客户端发现的实时 schema 为准。当前已验证服务版本的调用示例：

```text
工具：detect_matlab_toolboxes
参数：{}

工具：evaluate_matlab_code
参数：{"code":"disp(2+2); disp(version); disp(usejava('desktop'));"}
```

应看到实际数值 `4` 和 MATLAB 版本信息；默认 `nodesktop` 下桌面检查应为假。工具不可用时先检查 `matlab` 是否绑定到当前任务、MCP 命令是否存在、路径及 `WINDIR` 是否正确，再读具体错误。不要把未出现工具调用的自然语言回答当作连通证据。

## 4. 运行两个技能例程

完整依赖、输出清单和数值验收条件见 [用户测试例程](test-routines.md)。Simulink 例程需要 MATLAB 与 Simulink；普通控制原理作图例程需要 Control System Toolbox。调用前先确认脚本已安装到实际路径。

### 默认后台验证

先用 `evaluate_matlab_code` 显式设置输出父目录和显示选项，然后在**同一连接、同一 MATLAB 会话**调用 `run_matlab_file`。重启 MCP 会创建新会话，原工作区变量随之丢失，应重新设置配置。

```text
工具：evaluate_matlab_code
参数：{"code":"codex_demo_config = struct('output_root','D:/手机图片/matlab-agent/test-results','visible',false);"}

工具：run_matlab_file
参数：{"script_path":"C:\\Users\\15063\\.codex\\skills\\matlab-automatic-wwj\\assets\\codex_desktop_demo.m"}

工具：evaluate_matlab_code
参数：{"code":"doubao_simulink_summary = codex_demo_last_summary_path; disp(fileread(doubao_simulink_summary));"}

工具：run_matlab_file
参数：{"script_path":"C:\\Users\\15063\\.codex\\skills\\matlab-automatic-wwj\\assets\\control_theory_plots.m"}

工具：evaluate_matlab_code
参数：{"code":"doubao_control_summary = codex_demo_last_summary_path; disp(fileread(doubao_control_summary));"}
```

也可以在一次 `evaluate_matlab_code` 调用的 `code` 中执行以下 MATLAB 代码。这样配置与两个 `run` 在同一次工具调用中完成：

```matlab
codex_demo_config = struct( ...
    'output_root', 'D:/手机图片/matlab-agent/test-results', ...
    'visible', false);
run('C:/Users/15063/.codex/skills/matlab-automatic-wwj/assets/codex_desktop_demo.m');
doubao_simulink_summary = codex_demo_last_summary_path;
run('C:/Users/15063/.codex/skills/matlab-automatic-wwj/assets/control_theory_plots.m');
doubao_control_summary = codex_demo_last_summary_path;
disp(fileread(doubao_simulink_summary));
disp(fileread(doubao_control_summary));
```

不要省略 `output_root`：`run(绝对路径)` 会临时切换工作目录，脚本默认输出位置可能因此落进安装目录。两个例程各自在指定父目录创建独立子目录，运行后读取各自 `summary.json`，并检查用户要求的文件存在且非空。

### 用户要求真实 MATLAB 窗口

用户要在豆包中展示两例的真实桌面时，将该连接器的一条参数替换为：

```text
--matlab-display-mode=desktop
```

保留 `--matlab-session-mode=new`。等当前计算结束后保存并重启该连接器，让它创建自己的新 MATLAB 桌面会话。这里不会连接用户原先已打开的 MATLAB 窗口。

先实际执行 `disp(usejava('desktop'));`，确认返回真并查看真实桌面；然后在上面的例程配置中把 `'visible',false` 改为 `'visible',true`，再运行两个脚本。仅把 `visible` 改成真而仍使用 `nodesktop`，不能作为 MATLAB Desktop 展示成功的依据。

两个例程完成后应保留本次模型、Scope 和 Figure。保持连接器运行以便用户查看；MathWorks MCP 以 `new` 模式启动的 MATLAB 在服务停止时会随服务关闭。需要独立于连接器长期保留桌面时，使用 [用户测试例程中的 Windows 启动器](test-routines.md#windows-一条命令运行)。

可给豆包发送以下测试指令：

> 使用 matlab-automatic-wwj 技能和 matlab 连接器运行两个内置测试例程。在新建的真实 MATLAB 桌面里展示 Simulink 模型、Scope 与响应图，再展示普通 MATLAB 控制原理作图。脚本位于 C:\Users\15063\.codex\skills\matlab-automatic-wwj\assets；输出父目录设为 D:\手机图片\matlab-agent\test-results。先核对本次会话有桌面，设置 codex_demo_config.output_root 和 visible=true，再实际运行两个脚本。读取两份 summary.json、验证数值和要求的产物，完成后保留窗口与连接器。

豆包不一定使用 Codex 的 `$技能名` 调用语法，因此这里采用自然语言说明技能名，并明确资产路径。若豆包尚未加载技能，应先让它读取已安装技能的 `SKILL.md` 与本页，或按豆包当前提供的技能导入入口安装。

## 5. 适用范围与来源

- 本页配置适用于装有 MATLAB 的**豆包工作本地电脑**。未确认豆包最低版本号，也未确认普通聊天网页、手机端有相同配置入口。看不到入口时先核对产品、登录状态和当前版本，不杜撰其他菜单。
- [flomo 官方文档](https://help.flomoapp.com/advance/mcp/token.html)说明自定义连接器不会自动同步到其他电脑或手机；更换电脑需重新配置本机路径。
- [MediaClaw 官方文档](https://mediaclaw.app/docs/agent/setup)确认豆包工作的本地 STDIO 接法；具体字段补充来自 [Windows 一手配置记录](https://zhimayuandi.com/en/blog/doubao-custom-mcp-connectors/)。
- MATLAB 服务、参数与会话行为以 [MathWorks 官方仓库](https://github.com/matlab/matlab-mcp-server)及本项目使用的 [v0.13.0](https://github.com/matlab/matlab-mcp-server/releases/tag/v0.13.0)为准。
- 豆包模型 API 与扣子是不同接入入口。本页直接使用豆包工作；当前没有部署 HTTP 桥接。若另做扣子适配，[扣子官方 MCP 文档](https://docs.coze.cn/mcp)仍要求 Streamable HTTP/SSE，暂不支持 STDIO；[官方更新](https://docs.coze.cn/recent-updates)记载 2026-07-01 已下线新增发布至豆包渠道的入口，不能将该旧路线写成本页的替代配置步骤。
