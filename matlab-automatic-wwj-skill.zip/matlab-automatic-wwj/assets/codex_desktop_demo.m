%% MATLAB / Simulink 用户测试例程：真实模型、Scope 与响应图
% 默认保留真实窗口；自动验证时设 codex_demo_config.visible=false。
% 在 run(绝对路径) 前设置 output_root，避免 run 临时切换工作目录。
% 本文件自包含，可单独复制到任何用户工作目录再运行。
if exist('codex_demo_config', 'var')
    codex_demo_last_summary_path = packagedSimulinkDemo(codex_demo_config, mfilename('fullpath'));
else
    codex_demo_last_summary_path = packagedSimulinkDemo(struct(), mfilename('fullpath'));
end

function summaryPath = packagedSimulinkDemo(config, scriptPath)
    config = normalizeConfig(config);
    runDir = newRunDirectory(config.output_root, 'simulink');
    [~, token] = fileparts(tempname(runDir));
    model = matlab.lang.makeValidName(['codex_test_' token]);
    summaryPath = fullfile(runDir, 'summary.json');
    assignin('base', 'codex_demo_last_summary_path', summaryPath);
    files = struct('model', fullfile(runDir, [model '.slx']), ...
        'mat', fullfile(runDir, 'response.mat'), 'csv', fullfile(runDir, 'response.csv'), ...
        'response_png', fullfile(runDir, 'response.png'), 'model_png', fullfile(runDir, 'model.png'), ...
        'summary', summaryPath);
    state = struct('schema_version', 1, 'routine', 'simulink', 'status', 'running', ...
        'started_at_utc', utcNow(), 'matlab_version', version, 'matlab_release', version('-release'), ...
        'output_directory', runDir, 'visible_requested', config.visible, 'files', files);
    fig = gobjects(0);
    lineActual = gobjects(0);
    ax = gobjects(0);
    oldFolder = pwd;
    folderCleanup = onCleanup(@() cd(oldFolder)); %#ok<NASGU>
    try
        writeJson(summaryPath, state);
        cd(runDir);
        state.license_test = struct('MATLAB', logical(license('test', 'MATLAB')), ...
            'Simulink', logical(license('test', 'Simulink')));
        sl = ver('simulink');
        assert(~isempty(sl) && state.license_test.Simulink, 'CodexTest:SimulinkUnavailable', ...
            'Simulink must be installed and its license test must pass.');
        state.simulink_version = sl(1).Version;
        assert(~bdIsLoaded(model), 'CodexTest:ModelCollision', 'Generated model name is already loaded.');
        load_system('simulink');
        new_system(model);
        if ~config.visible
            % Anonymous closures capture this run's name/handle by value.
            % Local cleanup functions do not access a destroyed parent workspace.
            modelCleanup = onCleanup(@() closeTestModel(model)); %#ok<NASGU>
        end
        set_param(model, 'StartTime', '0', 'StopTime', '10', 'SolverType', 'Fixed-step', ...
            'Solver', 'ode4', 'FixedStep', '0.01', 'ReturnWorkspaceOutputs', 'on', ...
            'SaveTime', 'on', 'TimeSaveName', 'tout', 'SaveOutput', 'off', 'SignalLogging', 'off');
        add_block('simulink/Sources/Step', [model '/Unit Step'], 'Time', '0', ...
            'Before', '0', 'After', '1', 'SampleTime', '0', 'Position', [50 105 95 145]);
        add_block('simulink/Continuous/Transfer Fcn', [model '/First Order Plant'], ...
            'Numerator', '[1]', 'Denominator', '[2 1]', 'Position', [180 95 330 155]);
        add_block('simulink/Sinks/To Workspace', [model '/Simulation Data'], ...
            'VariableName', 'response', 'SaveFormat', 'Timeseries', 'MaxDataPoints', 'inf', ...
            'Decimation', '1', 'SampleTime', '-1', 'Position', [455 80 565 120]);
        add_block('simulink/Sinks/Scope', [model '/Live Scope'], 'Position', [475 185 520 230]);
        add_line(model, 'Unit Step/1', 'First Order Plant/1', 'autorouting', 'on');
        add_line(model, 'First Order Plant/1', 'Simulation Data/1', 'autorouting', 'on');
        add_line(model, 'First Order Plant/1', 'Live Scope/1', 'autorouting', 'on');
        if config.visible
            parameters = get_param(model, 'ObjectParameters');
            if isfield(parameters, 'EnablePacing') && isfield(parameters, 'PacingRate')
                set_param(model, 'EnablePacing', 'on', 'PacingRate', '1');
            end
        end
        save_system(model, files.model);
        if config.visible
            if usejava('desktop')
                edit(scriptPath);
            end
            open_system(model);
            set_param(model, 'ZoomFactor', 'FitSystem');
            open_system([model '/Live Scope']);
            drawnow;
        end
        state.phase = 'simulating';
        writeJson(summaryPath, state);
        out = sim(model, 'ReturnWorkspaceOutputs', 'on');
        [t, y, reference, maxError, response] = verifyResponse(out);
        figureVisibility = 'off';
        if config.visible
            figureVisibility = 'on';
        end
        fig = figure('Name', 'MATLAB / Simulink 用户测试 | 一阶系统', ...
            'NumberTitle', 'off', 'Color', 'w', 'Visible', figureVisibility, ...
            'WindowStyle', 'normal', 'Position', [160 120 1040 700]);
        if ~config.visible
            figureCleanup = onCleanup(@() closeTestFigure(fig)); %#ok<NASGU>
        end
        ax = axes(fig, 'Position', [0.11 0.20 0.84 0.69]);
        lineActual = plot(ax, t, y, 'LineWidth', 2.6, 'Color', [0.08 0.36 0.74]);
        hold(ax, 'on');
        plot(ax, t, reference, '--', 'LineWidth', 1.7, 'Color', [0.94 0.42 0.15]);
        grid(ax, 'on');
        xlabel(ax, 'Time (s)'); ylabel(ax, 'Output');
        title(ax, {'Actual Simulink output: G(s) = 1/(2s+1)', ...
            sprintf('%d samples | maximum error %.3g', numel(t), maxError)});
        legend(ax, {'Simulink / ode4', 'Analytical: 1 - exp(-t/2)'}, 'Location', 'southeast');
        set(ax, 'FontSize', 12, 'XLim', [0 10], 'YLim', [0 1.05], 'Box', 'off');
        if config.visible
            uicontrol(fig, 'Style', 'pushbutton', 'String', 'Run Simulink again', ...
                'Units', 'normalized', 'Position', [0.32 0.045 0.36 0.07], ...
                'FontSize', 11, 'Callback', @rerunSimulation);
        end
        drawnow;
        saveResponse(out, response, t, y, reference, maxError);
        try
            print(['-s' model], '-dpng', '-r160', files.model_png);
            assert(isfile(files.model_png), 'CodexTest:MissingModelImage', 'Model image export produced no file.');
            state.model_image_status = 'exported';
        catch imageFailure
            state.model_image_status = 'unavailable';
            state.model_image_message = imageFailure.message;
            state.files.model_png = '';
        end
        required = {'model', 'mat', 'csv', 'response_png'};
        for k = 1:numel(required)
            artifact = dir(files.(required{k}));
            assert(~isempty(artifact) && artifact(1).bytes > 0, ...
                'CodexTest:MissingArtifact', 'A required output artifact is missing or empty.');
        end
        state.model = struct('name', model, 'transfer_function', '1/(2*s+1)', ...
            'solver', 'ode4', 'fixed_step_s', 0.01, 'stop_time_s', 10);
        state.display = struct('model_open', get_param(model, 'Open'), ...
            'figure_visible', get(fig, 'Visible'), 'windows_retained', config.visible);
        state.phase = 'complete';
        state.status = 'success';
        state.completed_at_utc = utcNow();
        writeJson(summaryPath, state);
        fprintf('PASS: Simulink; %d samples; maximum error %.12g; y(10)=%.12g\n', ...
            numel(t), maxError, y(end));
        fprintf('MATLAB_AGENT_RESULT=%s\n', summaryPath);
        if config.visible
            figure(fig);
        end
    catch failure
        recordFailure(failure);
        rethrow(failure);
    end

    function saveResponse(out, response, t, y, reference, maxError)
        save(files.mat, 'out', 'response', 't', 'y', 'reference', 'maxError');
        writetable(table(t, y, reference, abs(y-reference), 'VariableNames', ...
            {'time_s', 'simulink_output', 'analytical_output', 'absolute_error'}), ...
            files.csv, 'Encoding', 'UTF-8');
        exportgraphics(ax, files.response_png, 'Resolution', 160, 'BackgroundColor', 'white');
        state.validation = struct('passed', true, 'sample_count', numel(t), ...
            'max_absolute_error', maxError, 'absolute_error_tolerance', 1e-4, ...
            'maximum_sample_gap_s', max(diff(t)), 'final_time_s', t(end), ...
            'final_value', y(end), 'analytical_final_value', reference(end));
    end

    function rerunSimulation(button, ~)
        set(button, 'Enable', 'off', 'String', 'Simulating...');
        buttonCleanup = onCleanup(@() restoreTestButton(button)); %#ok<NASGU>
        try
            state.status = 'running';
            state.phase = 'rerunning';
            writeJson(summaryPath, state);
            drawnow;
            fresh = sim(model, 'ReturnWorkspaceOutputs', 'on');
            [freshT, freshY, freshRef, freshError, data] = verifyResponse(fresh);
            set(lineActual, 'XData', freshT, 'YData', freshY);
            saveResponse(fresh, data, freshT, freshY, freshRef, freshError);
            title(ax, {'Actual Simulink output: G(s) = 1/(2s+1)', ...
                sprintf('Rerun verified | maximum error %.3g', freshError)});
            state.status = 'success';
            state.phase = 'complete';
            state.completed_at_utc = utcNow();
            if isfield(state, 'error'), state = rmfield(state, 'error'); end
            writeJson(summaryPath, state);
        catch failure
            recordFailure(failure);
            errordlg(failure.message, 'Simulation verification failed');
        end
    end

    function recordFailure(failure)
        state.status = 'failed';
        state.completed_at_utc = utcNow();
        state.error = struct('identifier', failure.identifier, 'message', failure.message, ...
            'report', getReport(failure, 'extended', 'hyperlinks', 'off'));
        try
            writeJson(summaryPath, state);
        catch writeFailure
            fprintf(2, 'Could not save failure summary: %s\n', writeFailure.message);
        end
    end
end

function closeTestModel(model)
    if bdIsLoaded(model)
        close_system(model, 0);
    end
end

function closeTestFigure(fig)
    if isgraphics(fig, 'figure')
        delete(fig);
    end
end

function restoreTestButton(button)
    if isgraphics(button)
        set(button, 'Enable', 'on', 'String', 'Run Simulink again');
    end
end

function [t, y, reference, maxError, response] = verifyResponse(out)
    response = out.get('response');
    assert(isa(response, 'timeseries'), 'CodexTest:OutputType', 'Expected a To Workspace timeseries.');
    t = double(response.Time(:)); y = double(response.Data(:));
    assert(numel(t) == numel(y) && numel(t) >= 1001 && all(isfinite(t)) && ...
        all(isfinite(y)) && all(diff(t) > 0) && abs(t(1)) < 1e-9 && ...
        abs(t(end)-10) < 1e-9 && max(diff(t)) <= 0.0100001, ...
        'CodexTest:InvalidData', 'Simulation must cover 0 to 10 s with at least 1001 finite samples.');
    reference = 1-exp(-t/2);
    maxError = max(abs(y-reference));
    assert(maxError < 1e-4, 'CodexTest:Accuracy', 'Simulation exceeds the 1e-4 error tolerance.');
end

function config = normalizeConfig(config)
    assert(isstruct(config) && isscalar(config), 'CodexTest:InvalidConfig', 'codex_demo_config must be a scalar struct.');
    if ~isfield(config, 'visible'), config.visible = true; end
    assert(islogical(config.visible) && isscalar(config.visible), ...
        'CodexTest:InvalidConfig', 'visible must be logical true or false.');
    if ~isfield(config, 'output_root'), config.output_root = fullfile(pwd, 'matlab-skill-tests'); end
    assert((ischar(config.output_root) && isrow(config.output_root)) || ...
        (isstring(config.output_root) && isscalar(config.output_root)), ...
        'CodexTest:InvalidConfig', 'output_root must be a nonempty path.');
    config.output_root = char(config.output_root);
    assert(~isempty(config.output_root), 'CodexTest:InvalidConfig', 'output_root must be nonempty.');
    if isempty(regexp(config.output_root, '^([A-Za-z]:[\\/]|[\\/])', 'once'))
        config.output_root = fullfile(pwd, config.output_root);
    end
end

function runDir = newRunDirectory(outputRoot, prefix)
    if ~isfolder(outputRoot)
        [ok, message] = mkdir(outputRoot);
        assert(ok, 'CodexTest:OutputDirectory', '%s', message);
    end
    [~, uniquePart] = fileparts(tempname(outputRoot));
    runDir = fullfile(outputRoot, [prefix '_' char(datetime('now', 'Format', 'yyyyMMdd_HHmmss_SSS')) '_' uniquePart]);
    assert(~isfolder(runDir), 'CodexTest:ExistingRun', 'Output directory already exists.');
    [ok, message] = mkdir(runDir);
    assert(ok, 'CodexTest:OutputDirectory', '%s', message);
end

function value = utcNow()
    value = char(datetime('now', 'TimeZone', 'UTC', 'Format', 'yyyy-MM-dd''T''HH:mm:ss.SSS''Z'''));
end

function writeJson(path, value)
    [fid, message] = fopen(path, 'w', 'n', 'UTF-8');
    assert(fid ~= -1, 'CodexTest:FileWrite', '%s', message);
    fileCleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>
    fprintf(fid, '%s\n', jsonencode(value, 'PrettyPrint', true));
end
