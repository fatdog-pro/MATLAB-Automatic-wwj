% CODEX_FIRST_ORDER_DEMO Build, simulate, and verify an actual Simulink model.
% Run from any folder:
%   run('D:\手机图片\matlab-agent\examples\codex_first_order_demo.m')
% Every invocation writes a new outputs/<run-id>/ directory. No GUI is opened.
% Only the model and figure created by this invocation are closed.
codexFirstOrderDemo(mfilename('fullpath'));

function codexFirstOrderDemo(scriptPath)
    projectRoot = fileparts(fileparts(scriptPath));
    outputsRoot = fullfile(projectRoot, 'outputs');
    if ~isfolder(outputsRoot)
        mkdir(outputsRoot);
    end
    [~, uniquePart] = fileparts(tempname(outputsRoot));
    runId = ['first_order_' char(datetime('now', 'Format', 'yyyyMMdd_HHmmss_SSS')) '_' uniquePart];
    runDir = fullfile(outputsRoot, runId);
    assert(~isfolder(runDir), 'CodexDemo:ExistingRun', 'Output directory already exists.');
    [madeDir, message] = mkdir(runDir);
    assert(madeDir, 'CodexDemo:OutputDirectory', '%s', message);
    modelName = matlab.lang.makeValidName(['codex_first_order_' uniquePart]);
    modelName = modelName(1:min(namelengthmax, numel(modelName)));
    paths = struct('model', fullfile(runDir, [modelName '.slx']), ...
        'mat', fullfile(runDir, 'response.mat'), ...
        'csv', fullfile(runDir, 'response.csv'), ...
        'response_png', fullfile(runDir, 'response.png'), ...
        'model_png', fullfile(runDir, 'model.png'), ...
        'summary', fullfile(runDir, 'summary.json'));
    summary = struct('schema_version', 1, 'status', 'running', 'run_id', runId, ...
        'started_at_utc', utcTimestamp(), 'output_directory', runDir, ...
        'matlab_version', version, 'matlab_release', version('-release'), ...
        'matlab_root', matlabroot, 'simulink_version', '', ...
        'license_test', struct(), 'files', paths, ...
        'model_image_status', 'not_attempted');
    % Keep incidental Simulink files in this run, and restore the caller's folder.
    previousFolder = pwd;
    folderCleanup = onCleanup(@() cd(previousFolder)); %#ok<NASGU>
    cd(runDir);
    try
        summary.license_test.MATLAB = logical(license('test', 'MATLAB'));
        summary.license_test.Simulink = logical(license('test', 'Simulink'));
        summary.license_test.Control_Toolbox = logical(license('test', 'Control_Toolbox'));
        slVersion = ver('simulink');
        assert(~isempty(slVersion), 'CodexDemo:MissingSimulink', 'Simulink is not installed.');
        summary.simulink_version = slVersion(1).Version;
        assert(summary.license_test.Simulink, 'CodexDemo:NoSimulinkLicense', ...
            'The Simulink license test failed.');
        assert(~bdIsLoaded(modelName), 'CodexDemo:ModelNameCollision', ...
            'A model with this run name is already loaded.');
        load_system('simulink');
        new_system(modelName);
        modelCleanup = onCleanup(@() closeDemoModel(modelName)); %#ok<NASGU>
        set_param(modelName, 'StartTime', '0', 'StopTime', '10', ...
            'SolverType', 'Fixed-step', 'Solver', 'ode4', 'FixedStep', '0.01', ...
            'ReturnWorkspaceOutputs', 'on', 'SaveTime', 'on', 'TimeSaveName', 'tout', ...
            'SaveOutput', 'off', 'SignalLogging', 'off');
        add_block('simulink/Sources/Step', [modelName '/Unit Step'], ...
            'Time', '0', 'Before', '0', 'After', '1', 'SampleTime', '0', ...
            'Position', [60 95 100 135]);
        add_block('simulink/Continuous/Transfer Fcn', [modelName '/Plant 1 over (2s+1)'], ...
            'Numerator', '[1]', 'Denominator', '[2 1]', ...
            'Position', [185 85 310 145]);
        add_block('simulink/Sinks/To Workspace', [modelName '/Output Timeseries'], ...
            'VariableName', 'response', 'SaveFormat', 'Timeseries', ...
            'MaxDataPoints', 'inf', 'Decimation', '1', 'SampleTime', '-1', ...
            'Position', [395 95 500 135]);
        add_line(modelName, 'Unit Step/1', 'Plant 1 over (2s+1)/1', 'autorouting', 'on');
        add_line(modelName, 'Plant 1 over (2s+1)/1', 'Output Timeseries/1', 'autorouting', 'on');
        save_system(modelName, paths.model);
        simulationOutput = sim(modelName, 'ReturnWorkspaceOutputs', 'on');
        response = simulationOutput.get('response');
        assert(isa(response, 'timeseries'), 'CodexDemo:OutputType', ...
            'Expected an actual Simulink To Workspace timeseries.');
        time = double(response.Time(:));
        simulated = double(response.Data(:));
        analytical = 1 - exp(-time / 2);
        absoluteError = abs(simulated - analytical);
        assert(numel(time) == numel(simulated) && numel(time) >= 1001, ...
            'CodexDemo:InsufficientSamples', 'Expected at least 1001 matching samples.');
        assert(all(isfinite(time)) && all(isfinite(simulated)) && ...
            all(diff(time) > 0), 'CodexDemo:InvalidData', ...
            'Simulation data must be finite with strictly increasing time.');
        assert(abs(time(1)) < 1e-10 && abs(time(end) - 10) < 1e-10 && ...
            max(diff(time)) <= 0.0100001, 'CodexDemo:TimeCoverage', ...
            'Samples must cover 0 to 10 s with a maximum 0.01 s gap.');
        maxAbsoluteError = max(absoluteError);
        assert(maxAbsoluteError < 1e-4, 'CodexDemo:Accuracy', ...
            'Maximum absolute error %.12g exceeds the 1e-4 threshold.', maxAbsoluteError);
        summary.model = struct('transfer_function', '1/(2*s+1)', 'time_constant_s', 2, ...
            'step_time_s', 0, 'step_amplitude', 1, 'stop_time_s', 10, ...
            'solver', 'ode4', 'fixed_step_s', 0.01);
        summary.validation = struct('passed', true, 'sample_count', numel(time), ...
            'maximum_sample_gap_s', max(diff(time)), 'absolute_error_tolerance', 1e-4, ...
            'max_absolute_error', maxAbsoluteError, 'final_time_s', time(end), ...
            'final_value', simulated(end), 'analytical_final_value', analytical(end), ...
            'asymptotic_value', 1);
        responseTable = table(time, simulated, analytical, absoluteError, ...
            'VariableNames', {'time_s', 'simulink_output', 'analytical_output', 'absolute_error'});
        save(paths.mat, 'simulationOutput', 'response', 'time', 'simulated', ...
            'analytical', 'absoluteError', 'maxAbsoluteError', '-v7');
        writetable(responseTable, paths.csv, 'Encoding', 'UTF-8');
        renderResponse(time, simulated, analytical, absoluteError, maxAbsoluteError, paths.response_png);
        % MathWorks print can export a loaded model without opening its editor.
        % Some no-display MATLAB environments disable Simulink diagram printing.
        try
            print(['-s' modelName], '-dpng', '-r180', paths.model_png);
            assert(isfile(paths.model_png), 'CodexDemo:ModelImageMissing', ...
                'The model image export did not create a file.');
            summary.model_image_status = 'exported';
        catch imageError
            summary.model_image_status = 'unavailable';
            summary.model_image_message = imageError.message;
            summary.files.model_png = '';
            warning('CodexDemo:ModelImageUnavailable', 'Optional model image unavailable: %s', imageError.message);
        end
        requiredFiles = {'model', 'mat', 'csv', 'response_png'};
        for k = 1:numel(requiredFiles)
            artifact = dir(paths.(requiredFiles{k}));
            assert(~isempty(artifact) && artifact(1).bytes > 0, ...
                'CodexDemo:MissingArtifact', 'A required output file is missing or empty.');
        end
        summary.status = 'success';
        summary.completed_at_utc = utcTimestamp();
        writeSummary(paths.summary, summary);
        fprintf('\nMATLAB_AGENT_RESULT=%s\n', paths.summary);
        fprintf('PASS: %d samples; max absolute error %.12g; y(10)=%.12g\n', ...
            numel(time), maxAbsoluteError, simulated(end));
    catch failure
        summary.status = 'failed';
        summary.completed_at_utc = utcTimestamp();
        summary.error = struct('identifier', failure.identifier, 'message', failure.message, ...
            'report', getReport(failure, 'extended', 'hyperlinks', 'off'));
        try
            writeSummary(paths.summary, summary);
            fprintf(2, '\nMATLAB_AGENT_RESULT=%s\n', paths.summary);
        catch summaryError
            fprintf(2, 'Could not write failure summary: %s\n', summaryError.message);
        end
        rethrow(failure);
    end
end

function renderResponse(time, simulated, analytical, absoluteError, maxError, outputPath)
    fig = figure('Visible', 'off', 'Color', 'white', ...
        'Position', [100 100 1200 760], 'Name', 'Codex Simulink verification');
    figureCleanup = onCleanup(@() close(fig)); %#ok<NASGU>
    layout = tiledlayout(fig, 2, 1, 'TileSpacing', 'compact', 'Padding', 'compact');
    ax1 = nexttile(layout);
    plot(ax1, time, simulated, 'LineWidth', 2.4, 'Color', [0.10 0.34 0.66]);
    hold(ax1, 'on');
    plot(ax1, time, analytical, '--', 'LineWidth', 1.7, 'Color', [0.91 0.40 0.18]);
    yline(ax1, 1, ':', 'Steady state', 'Color', [0.45 0.48 0.53]);
    ylabel(ax1, 'Output');
    title(ax1, 'First-order step response  |  G(s) = 1 / (2s + 1)', 'FontWeight', 'bold');
    legend(ax1, {'Simulink / ode4', 'Analytical: 1 - exp(-t/2)'}, ...
        'Location', 'southeast', 'Box', 'off');
    ylim(ax1, [0 1.07]);
    ax2 = nexttile(layout);
    plot(ax2, time, absoluteError, 'LineWidth', 1.8, 'Color', [0.05 0.53 0.47]);
    xlabel(ax2, 'Time (s)');
    ylabel(ax2, 'Absolute error');
    title(ax2, sprintf('Verification passed  |  max error = %.3g  |  %d samples', ...
        maxError, numel(time)), 'FontWeight', 'normal');
    for ax = [ax1 ax2]
        set(ax, 'FontName', 'Arial', 'FontSize', 12, 'Box', 'off', ...
            'XLim', [0 10], 'XGrid', 'on', 'YGrid', 'on', 'GridAlpha', 0.12);
    end
    exportgraphics(fig, outputPath, 'Resolution', 180, 'BackgroundColor', 'white');
end

function value = utcTimestamp()
    value = char(datetime('now', 'TimeZone', 'UTC', ...
        'Format', 'yyyy-MM-dd''T''HH:mm:ss.SSS''Z'''));
end

function writeSummary(path, summary)
    [fid, message] = fopen(path, 'w', 'n', 'UTF-8');
    assert(fid ~= -1, 'CodexDemo:SummaryWrite', '%s', message);
    fileCleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>
    fprintf(fid, '%s\n', jsonencode(summary, 'PrettyPrint', true));
end

function closeDemoModel(modelName)
    if bdIsLoaded(modelName)
        close_system(modelName, 0);
    end
end
