%% 自动控制原理用户测试：普通 MATLAB 代码计算阶跃、Bode 和根轨迹
% 需要 Control System Toolbox，不调用 Simulink。
% 默认显示图窗；codex_demo_config.visible=false 可用于自动验证。
% output_root 默认 fullfile(pwd,'matlab-skill-tests')。使用 run(绝对路径)
% 时，请先显式设置 output_root。本文件自包含，可单独复制后运行。
if exist('codex_demo_config', 'var')
    codex_demo_last_summary_path = packagedControlDemo(codex_demo_config, mfilename('fullpath'));
else
    codex_demo_last_summary_path = packagedControlDemo(struct(), mfilename('fullpath'));
end

function summaryPath = packagedControlDemo(config, scriptPath)
    config = normalizeConfig(config);
    outputDir = newRunDirectory(config.output_root, 'control');
    summaryPath = fullfile(outputDir, 'summary.json');
    assignin('base', 'codex_demo_last_summary_path', summaryPath);
    files = struct('figure_png', fullfile(outputDir, 'control_theory.png'), ...
        'figure_editable', fullfile(outputDir, 'control_theory.fig'), ...
        'mat', fullfile(outputDir, 'control_data.mat'), ...
        'step_metrics', fullfile(outputDir, 'step_metrics.csv'), ...
        'step_responses', fullfile(outputDir, 'step_responses.csv'), ...
        'bode', fullfile(outputDir, 'bode_response.csv'), ...
        'root_locus', fullfile(outputDir, 'root_locus.csv'), 'summary', summaryPath);
    state = struct('schema_version', 1, 'routine', 'control', 'status', 'running', ...
        'started_at_utc', utcNow(), 'matlab_version', version, 'matlab_release', version('-release'), ...
        'output_directory', outputDir, 'visible_requested', config.visible, 'files', files);
    demoFigure = gobjects(0);
    try
        writeJson(summaryPath, state);
        state.license_test = struct('MATLAB', logical(license('test', 'MATLAB')), ...
            'Control_Toolbox', logical(license('test', 'Control_Toolbox')));
        toolbox = ver('control');
        assert(~isempty(toolbox) && state.license_test.Control_Toolbox, ...
            'CodexTest:ControlUnavailable', 'Control System Toolbox must be installed and its license test must pass.');
        state.control_toolbox_version = toolbox(1).Version;
        if config.visible && usejava('desktop')
            edit(scriptPath);
        end

        %% 1. 二阶系统：用真实 step 结果比较五种阻尼比
        wn = 4;
        zeta = [0.2 0.5 0.7 1.0 1.5];
        t = (0:0.005:12)';
        s = tf('s');
        response = zeros(numel(t), numel(zeta));
        analytical = response;
        overshoot = zeros(size(zeta));
        theoreticalOvershoot = zeros(size(zeta));
        settlingTime = zeros(size(zeta));
        riseTime = zeros(size(zeta));
        systems = cell(size(zeta));
        for k = 1:numel(zeta)
            z = zeta(k);
            systems{k} = wn^2 / (s^2 + 2*z*wn*s + wn^2);
            response(:,k) = step(systems{k}, t);
            info = stepinfo(response(:,k), t, 1, 'SettlingTimeThreshold', 0.02, 'RiseTimeLimits', [0.1 0.9]);
            overshoot(k) = info.Overshoot;
            settlingTime(k) = info.SettlingTime;
            riseTime(k) = info.RiseTime;
            if z < 1
                wd = wn*sqrt(1-z^2);
                analytical(:,k) = 1-exp(-z*wn*t).*(cos(wd*t)+z/sqrt(1-z^2)*sin(wd*t));
                theoreticalOvershoot(k) = 100*exp(-pi*z/sqrt(1-z^2));
            elseif z == 1
                analytical(:,k) = 1-exp(-wn*t).*(1+wn*t);
            else
                p1 = -wn*(z-sqrt(z^2-1));
                p2 = -wn*(z+sqrt(z^2-1));
                analytical(:,k) = 1+(p2*exp(p1*t)-p1*exp(p2*t))/(p1-p2);
            end
        end
        maxStepError = max(abs(response-analytical), [], 'all');
        maxOvershootError = max(abs(overshoot-theoreticalOvershoot));
        assert(numel(t) == 2401 && all(isfinite(response), 'all') && maxStepError < 1e-8, ...
            'CodexTest:StepAccuracy', 'Step response failed its independent analytical verification.');
        assert(all(isfinite([riseTime settlingTime overshoot])) && maxOvershootError < 0.01, ...
            'CodexTest:OvershootAccuracy', 'Overshoot or response metrics failed verification.');
        metrics = table(zeta', overshoot', theoreticalOvershoot', riseTime', settlingTime', ...
            'VariableNames', {'DampingRatio', 'Overshoot_pct', 'AnalyticalOvershoot_pct', ...
            'RiseTime_10_90_s', 'SettlingTime_2pct_s'});

        %% 2. Bode：同时验证幅值和相位对应的复数频率响应
        G = wn^2/(s^2 + 4*s + wn^2);
        w = logspace(-1, 2, 800)';
        [magnitude, phase] = bode(G, w);
        magnitude = reshape(magnitude, [], 1);
        phase = reshape(phase, [], 1);
        magnitudeDB = 20*log10(magnitude);
        exactFrequencyResponse = wn^2 ./ ((1i*w).^2 + 4*(1i*w) + wn^2);
        actualFrequencyResponse = magnitude.*exp(1i*phase*pi/180);
        maxBodeError = max(abs(actualFrequencyResponse-exactFrequencyResponse));
        assert(all(isfinite([magnitude; phase])) && maxBodeError < 1e-10, ...
            'CodexTest:BodeAccuracy', 'Bode magnitude/phase failed independent complex-response verification.');

        %% 3. 独立三阶系统：根轨迹与 Routh 稳定边界
        L = 1/(s*(s+2)*(s+5));
        gains = [0 logspace(-3, log10(250), 1500)];
        [locus, gains] = rlocus(L, gains);
        gains = reshape(gains, 1, []);
        criticalGain = 70;
        criticalPoles = roots([1 7 10 criticalGain]);
        % 特征多项式 s^3+7s^2+10s+K=0；分母使残差可跨量级比较。
        locusResidual = abs(locus.^3+7*locus.^2+10*locus+gains) ./ ...
            (1+abs(locus).^3+7*abs(locus).^2+10*abs(locus)+abs(gains));
        maxRootResidual = max(locusResidual, [], 'all');
        stablePoles = pole(feedback(69*L, 1));
        unstablePoles = pole(feedback(71*L, 1));
        assert(size(locus, 1) == 3 && size(locus, 2) == 1501 && ...
            all(isfinite(locus), 'all') && maxRootResidual < 1e-10, ...
            'CodexTest:RootLocusAccuracy', 'Root locus failed its characteristic-polynomial verification.');
        assert(all(real(stablePoles) < 0) && any(real(unstablePoles) > 0), ...
            'CodexTest:StabilityBoundary', 'The stable/unstable side checks around K=70 failed.');
        boundaryResidual = max(abs(polyval([1 7 10 criticalGain], [-7; 1i*sqrt(10); -1i*sqrt(10)])));
        assert(boundaryResidual < 1e-10, 'CodexTest:CriticalPoles', 'The K=70 critical poles failed verification.');

        %% 4. 普通 MATLAB Figure：阶跃、根轨迹、Bode 幅频及相频
        colors = [0.10 0.35 0.70; 0.88 0.34 0.15; 0.02 0.52 0.43; ...
            0.53 0.33 0.69; 0.54 0.49 0.32];
        figureVisibility = 'off';
        if config.visible, figureVisibility = 'on'; end
        demoFigure = figure('Name', '自动控制原理 | MATLAB 普通代码作图', ...
            'NumberTitle', 'off', 'Color', 'w', 'Visible', figureVisibility, ...
            'WindowStyle', 'normal', 'Position', [80 80 1400 900]);
        if ~config.visible
            % Capture only the created figure, not the exiting function workspace.
            figureCleanup = onCleanup(@() closeTestFigure(demoFigure)); %#ok<NASGU>
        end
        layout = tiledlayout(demoFigure, 2, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
        axStep = nexttile(layout, 1);
        hold(axStep, 'on');
        handles = gobjects(1, numel(zeta));
        labels = cell(size(zeta));
        for k = 1:numel(zeta)
            handles(k) = plot(axStep, t, response(:,k), 'LineWidth', 1.9, 'Color', colors(k,:));
            labels{k} = sprintf('zeta = %.1f | overshoot %.1f%%', zeta(k), overshoot(k));
        end
        yline(axStep, 1, ':', 'Color', [0.5 0.5 0.5], 'HandleVisibility', 'off');
        xlim(axStep, [0 8]); ylim(axStep, [0 1.65]);
        title(axStep, {'二阶系统的单位阶跃响应', 'G(s)=16/(s^2+8ζs+16), ω_n=4 rad/s'});
        xlabel(axStep, 'Time (s)'); ylabel(axStep, 'Output');
        legend(axStep, handles, labels, 'Location', 'northeast', 'FontSize', 8, 'Box', 'off');
        axRoot = nexttile(layout, 2);
        hold(axRoot, 'on');
        for k = 1:size(locus, 1)
            plot(axRoot, real(locus(k,:)), imag(locus(k,:)), 'LineWidth', 1.8, 'Color', colors(k,:));
        end
        plot(axRoot, [-5 -2 0], [0 0 0], 'kx', 'MarkerSize', 10, 'LineWidth', 2);
        plot(axRoot, real(criticalPoles), imag(criticalPoles), 'ro', 'MarkerSize', 8, 'LineWidth', 1.8);
        xline(axRoot, 0, ':', 'Color', [0.4 0.4 0.4]);
        yline(axRoot, 0, ':', 'Color', [0.4 0.4 0.4]);
        title(axRoot, {'独立三阶系统：根轨迹', 'L(s)=1/[s(s+2)(s+5)],  0 ≤ K ≤ 250'});
        xlabel(axRoot, 'Real axis (1/s)'); ylabel(axRoot, 'Imaginary axis (1/s)');
        text(axRoot, -8.6, 5.4, {'稳定范围：0 < K < 70', '红圈：K=70，临界极点'}, ...
            'FontName', 'Microsoft YaHei', 'FontSize', 9);
        xlim(axRoot, [-9.5 2]); ylim(axRoot, [-6.5 6.5]);
        axMagnitude = nexttile(layout, 3);
        semilogx(axMagnitude, w, magnitudeDB, 'LineWidth', 2.1, 'Color', colors(1,:));
        xline(axMagnitude, 4, '--', 'ω_n=4', 'LabelVerticalAlignment', 'bottom');
        title(axMagnitude, {'Bode 幅频特性 | ζ=0.5', 'G(s)=16/(s^2+4s+16)'});
        xlabel(axMagnitude, 'Frequency (rad/s)'); ylabel(axMagnitude, 'Magnitude (dB)');
        axPhase = nexttile(layout, 4);
        semilogx(axPhase, w, phase, 'LineWidth', 2.1, 'Color', colors(3,:));
        yline(axPhase, -90, ':', '-90 deg');
        xline(axPhase, 4, '--');
        title(axPhase, {'Bode 相频特性 | ζ=0.5', '自然频率处相位为 -90 deg'});
        xlabel(axPhase, 'Frequency (rad/s)'); ylabel(axPhase, 'Phase (deg)');
        ylim(axPhase, [-185 5]);
        for ax = [axStep axRoot axMagnitude axPhase]
            set(ax, 'FontName', 'Microsoft YaHei', 'FontSize', 10, 'Box', 'off');
            grid(ax, 'on'); ax.GridAlpha = 0.12;
        end
        title(layout, '自动控制原理 · MATLAB 代码计算与作图', ...
            'FontName', 'Microsoft YaHei', 'FontSize', 17, 'FontWeight', 'bold');
        drawnow;

        %% 5. 保存可编辑图、PNG、数据与可机器读取的验收结果
        exportgraphics(demoFigure, files.figure_png, 'Resolution', 160, 'BackgroundColor', 'white');
        savefig(demoFigure, files.figure_editable);
        save(files.mat, 'wn', 'zeta', 't', 'systems', 'response', 'analytical', 'metrics', ...
            'w', 'magnitude', 'magnitudeDB', 'phase', 'exactFrequencyResponse', 'gains', 'locus', ...
            'criticalPoles', 'stablePoles', 'unstablePoles', 'maxStepError', 'maxBodeError', 'maxRootResidual');
        writetable(metrics, files.step_metrics, 'Encoding', 'UTF-8');
        stepTable = array2table([t response], 'VariableNames', ...
            {'time_s', 'zeta_0p2', 'zeta_0p5', 'zeta_0p7', 'zeta_1p0', 'zeta_1p5'});
        writetable(stepTable, files.step_responses, 'Encoding', 'UTF-8');
        writetable(table(w, magnitude, magnitudeDB, phase, 'VariableNames', ...
            {'frequency_rad_s', 'magnitude', 'magnitude_dB', 'phase_deg'}), files.bode, 'Encoding', 'UTF-8');
        gainGrid = repmat(gains, size(locus,1), 1);
        branchGrid = repmat((1:size(locus,1))', 1, numel(gains));
        writetable(table(gainGrid(:), branchGrid(:), real(locus(:)), imag(locus(:)), ...
            'VariableNames', {'gain', 'branch', 'pole_real', 'pole_imag'}), files.root_locus, 'Encoding', 'UTF-8');
        required = fieldnames(files);
        for k = 1:numel(required)
            if strcmp(required{k}, 'summary'), continue; end
            artifact = dir(files.(required{k}));
            assert(~isempty(artifact) && artifact(1).bytes > 0, ...
                'CodexTest:MissingArtifact', 'A required output artifact is missing or empty.');
        end
        state.validation = struct('passed', true, 'step_sample_count', numel(t), ...
            'step_system_count', numel(zeta), 'max_step_error', maxStepError, ...
            'step_error_tolerance', 1e-8, 'max_overshoot_error_percentage_points', maxOvershootError, ...
            'bode_sample_count', numel(w), 'max_bode_complex_error', maxBodeError, ...
            'bode_error_tolerance', 1e-10, 'root_locus_gain_count', numel(gains), ...
            'max_root_polynomial_relative_residual', maxRootResidual, 'root_residual_tolerance', 1e-10, ...
            'stable_at_gain_69', true, 'unstable_at_gain_71', true, 'critical_gain', criticalGain, ...
            'stable_gain_interval', [0 70], 'stability_endpoints_excluded', true);
        state.step_metrics = table2struct(metrics);
        state.display = struct('figure_visible', get(demoFigure, 'Visible'), 'windows_retained', config.visible);
        state.status = 'success';
        state.completed_at_utc = utcNow();
        writeJson(summaryPath, state);
        fprintf('PASS: MATLAB control plots; step error %.3g; Bode error %.3g; root residual %.3g\n', ...
            maxStepError, maxBodeError, maxRootResidual);
        fprintf('MATLAB_AGENT_RESULT=%s\n', summaryPath);
        if config.visible, figure(demoFigure); end
    catch failure
        state.status = 'failed';
        state.completed_at_utc = utcNow();
        state.error = struct('identifier', failure.identifier, 'message', failure.message, ...
            'report', getReport(failure, 'extended', 'hyperlinks', 'off'));
        try
            writeJson(summaryPath, state);
        catch writeFailure
            fprintf(2, 'Could not save failure summary: %s\n', writeFailure.message);
        end
        rethrow(failure);
    end
end

function closeTestFigure(fig)
    if isgraphics(fig, 'figure')
        delete(fig);
    end
end

function config = normalizeConfig(config)
    assert(isstruct(config) && isscalar(config), 'CodexTest:InvalidConfig', 'codex_demo_config must be a scalar struct.');
    if ~isfield(config, 'visible'), config.visible = true; end
    assert(islogical(config.visible) && isscalar(config.visible), ...
        'CodexTest:InvalidConfig', 'visible must be logical true or false.');
    if ~isfield(config, 'output_root'), config.output_root = fullfile(pwd, 'matlab-skill-tests'); end
    assert((ischar(config.output_root) && isrow(config.output_root)) || ...
        (isstring(config.output_root) && isscalar(config.output_root)), ...
        'CodexTest:InvalidConfig', 'output_root must be a nonempty path.');
    config.output_root = char(config.output_root);
    assert(~isempty(config.output_root), 'CodexTest:InvalidConfig', 'output_root must be nonempty.');
    if isempty(regexp(config.output_root, '^([A-Za-z]:[\\/]|[\\/])', 'once'))
        config.output_root = fullfile(pwd, config.output_root);
    end
end

function runDir = newRunDirectory(outputRoot, prefix)
    if ~isfolder(outputRoot)
        [ok, message] = mkdir(outputRoot);
        assert(ok, 'CodexTest:OutputDirectory', '%s', message);
    end
    [~, uniquePart] = fileparts(tempname(outputRoot));
    runDir = fullfile(outputRoot, [prefix '_' char(datetime('now', 'Format', 'yyyyMMdd_HHmmss_SSS')) '_' uniquePart]);
    assert(~isfolder(runDir), 'CodexTest:ExistingRun', 'Output directory already exists.');
    [ok, message] = mkdir(runDir);
    assert(ok, 'CodexTest:OutputDirectory', '%s', message);
end

function value = utcNow()
    value = char(datetime('now', 'TimeZone', 'UTC', 'Format', 'yyyy-MM-dd''T''HH:mm:ss.SSS''Z'''));
end

function writeJson(path, value)
    [fid, message] = fopen(path, 'w', 'n', 'UTF-8');
    assert(fid ~= -1, 'CodexTest:FileWrite', '%s', message);
    fileCleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>
    fprintf(fid, '%s\n', jsonencode(value, 'PrettyPrint', true));
end
